Semantic Kernel AI Agents deployment in an Azure Container App using a LLM from Azure AI Foundry.
